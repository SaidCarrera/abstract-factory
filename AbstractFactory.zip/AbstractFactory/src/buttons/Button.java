package buttons;

public interface Button {
    void paint();
}
