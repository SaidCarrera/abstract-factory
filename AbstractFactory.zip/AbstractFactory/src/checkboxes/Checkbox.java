package checkboxes;

public interface Checkbox {
    void paint();
}
